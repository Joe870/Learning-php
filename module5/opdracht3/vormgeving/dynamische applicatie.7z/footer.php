<!-- jou HTML voor een footer komt hier -->
<div class="footer">
<p>copyright 13-9-2023 Joëlle van Breugel</p>
</div>